import jjlog
import traffic_capture
import plugins
import proxies

# Items we store, as a kind of global or class variable
interface = ""
redirection_ports = ()

# IP address we're listening on, defaults to 0.0.0.0
# hostname

# Port we run the HTTP proxy on
# port
